# GitHub Actions build troubleshooting

If GitHub reports `chmod: cannot access 'gradlew': No such file or directory`, the workflow now locates the Android project automatically instead of assuming the repository root.

The workflow also runs the wrapper with `bash ./gradlew`, so the build does not depend on Git preserving the executable bit when files are uploaded through the GitHub web UI.

Required Android project files:
- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.properties`
- `gradle/wrapper/gradle-wrapper.jar`
- `settings.gradle.kts`
- `app/build.gradle.kts`

The CI job downloads/verifies the official Gradle Wrapper JAR when necessary, then builds `:app:assembleDebug`.
