package com.socialnetwork.app.data.model

/** Uploaded media descriptor shared by post and story upload flows. */
class UploadedMedia(
    val url: String,
    val path: String
)
