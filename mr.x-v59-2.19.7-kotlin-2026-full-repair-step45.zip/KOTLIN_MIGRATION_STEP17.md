# Kotlin Migration — Step 17

Updated the complete `MainActivityLegacy.kt` file rather than isolated methods.

Changes in this step:
- Added correct Kotlin `override` declarations for Android lifecycle methods.
- Made `onCreate` accept nullable `Bundle?` as required by the Android API.
- Added the missing generic type to the synchronized follow-target set.
- Repaired the remaining Java-style local `HttpResult r` declaration.
- Rechecked the source for obvious Java declarations, `new` expressions, and ternary operators.
- Kept `migration-source/MainActivityLegacy.java` temporarily as a comparison source until Android/Gradle compilation is available.

Validation note: standalone kotlinc cannot resolve Android SDK classes in this environment. No claim of APK build success is made here.
