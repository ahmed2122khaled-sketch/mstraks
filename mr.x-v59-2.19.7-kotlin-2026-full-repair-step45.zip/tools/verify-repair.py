#!/usr/bin/env python3
from pathlib import Path
import re, zipfile, sys

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT/'app/src/main/kotlin/com/socialnetwork/app/ui/MainActivity.kt').read_text()
secret = (ROOT/'app/src/main/kotlin/com/socialnetwork/app/security/SecretStore.kt').read_text()
monitor = (ROOT/'app/src/main/kotlin/com/socialnetwork/app/core/ConnectivityMonitor.kt').read_text()
endpoints = (ROOT/'app/src/main/kotlin/com/socialnetwork/app/network/ServiceEndpoints.kt').read_text()
offline = (ROOT/'app/src/main/kotlin/com/socialnetwork/app/data/local/OfflineStore.kt').read_text()
manifest = (ROOT/'app/src/main/AndroidManifest.xml').read_text()

def check(ok, msg):
    print(('PASS: ' if ok else 'FAIL: ') + msg)
    if not ok: sys.exit(1)

check(len(re.findall(r'override fun onNewIntent\(intent: Intent\)', main)) == 1,
      'MainActivity has exactly one onNewIntent implementation')
check('activeNetwork' in monitor and 'activeNetworkInfo' in monitor,
      'network detection has API 23+ and legacy fallback paths')
check('Build.VERSION.SDK_INT < Build.VERSION_CODES.N' in monitor and 'NET_CAPABILITY_INTERNET' in monitor,
      'API 23 network detection does not require VALIDATED')
check('registerNetworkCallback(request' in monitor,
      'pre-24 connectivity callback fallback exists')
check('url.startsWith(primary)' not in endpoints and 'url.startsWith(primary + "/rest/")' not in endpoints,
      'service routing does not rely on unsafe prefix matching')
check('pathFromTrustedService(value)' in endpoints and 'sameOriginOrigin' in endpoints and 'validRoutableUrl' in endpoints,
      'service routing validates the exact configured origin')
check('return -1L' in offline and 'Never evict' in offline,
      'offline queue refuses overflow instead of silently dropping old mutations')
check('android:screenOrientation="portrait"' not in manifest,
      'portrait lock removed for Android 16 large-screen adaptability')
check('versionCode = 52' in (ROOT/'app/build.gradle.kts').read_text(), 'version bumped after repair')
check('String[] storyLabels' not in main and 'loadStoryBar(storiesBar)' in main, 'story strip uses live backend data instead of sample names')
check('unregister()' in monitor and 'callback = null' in monitor, 'network callback is released on every supported API level')
check('networkAvailableAtStart = isNetworkAvailable()' in main and 'shouldQueueOffline(method, url)' in main, 'write mutations are queued only before a request can reach the server')
check('shouldQueueOffline(method, url, e)' not in main, 'no post-failure write requeue that can duplicate accepted mutations')
check('queueOfflineMedia(OFFLINE_POST_URL' in main and 'uploadMedia(media,mime)' in main, 'offline media is queued before upload and online upload is not blindly re-queued')
check('RejectedExecutionException' in main and 'private fun submitIo(task: () -> Unit)' in main and 'appExecutors.io().execute(' in main, 'executor saturation is handled without UI-thread crashes or caller-thread execution')
check('LEGACY_RSA_KEY_ALIAS' in main and 'ensureLegacyWrappedKey' in secret and 'Build.VERSION.SDK_INT' in secret, 'API 21-22 session key fallback is implemented without KeyGenParameterSpec')
check('versionName = \"2.19.7\"' in (ROOT/'app/build.gradle.kts').read_text(), 'version name matches repaired build')
check('DB_VERSION = 5' in offline and 'owner_user_id' in offline and 'fun getCached(url: String?, ownerUserId: String?)' in offline and 'fun putCached(url: String?, body: String?, ownerUserId: String?)' in offline, 'offline response cache is account-scoped with schema migration')
check('clearCache()' in offline and 'offlineStore.clearCache()' in main, 'logout clears locally cached account data')
check('ALTER TABLE cache ADD COLUMN owner_user_id' in offline and 'db.delete(\"cache\", null, null)' in offline, 'legacy cache rows are invalidated instead of being reassigned across accounts')
print('REPAIR STATIC CHECKS: PASS')

check('CURRENT_USER_ID' in main and 'owner_user_id' in offline and 'pendingOperationBelongsToUser' in main, 'offline mutations are bound to the authenticated account')
check('operation_id' in offline and 'X-MRX-Operation-ID' in main and 'X-Request-ID' in main, 'operation IDs are account-scoped and requests are traceable')
check('RECOVERY_STATE_TTL_MS' in main and 'constantTimeEquals' in main and 'callbackState' in main, 'password recovery callback requires one-time state')
