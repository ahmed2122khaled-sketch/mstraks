#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/gradle/wrapper/gradle-wrapper.jar"
KOTLINC="${KOTLINC:-$(command -v kotlinc || true)}"
if [[ -z "$KOTLINC" ]]; then
  echo "BUILD BLOCKED: Kotlin compiler (kotlinc) is required to build GradleBootstrap.kt" >&2
  exit 1
fi
"$KOTLINC" -include-runtime -d "$OUT" "$ROOT/tools/gradle-bootstrap/GradleBootstrap.kt"
TMP="$ROOT/tools/gradle-bootstrap/manifest.mf"
printf '%s\n' 'Manifest-Version: 1.0' 'Main-Class: GradleBootstrap' > "$TMP"
jar --update --file "$OUT" --manifest "$TMP"
sha256sum "$OUT" | tee "$ROOT/gradle/wrapper/gradle-wrapper-bootstrap.sha256"
