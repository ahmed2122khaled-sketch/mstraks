import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Comparator
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipInputStream

/**
 * Offline-friendly bootstrap used only when the official Gradle Wrapper JAR
 * has not yet been fetched. It downloads and verifies the pinned Gradle
 * distribution, extracts it into the Gradle user cache, then delegates all
 * arguments to Gradle.
 */
object GradleBootstrap {
    private const val VERSION = "9.7.1"
    private const val DISTRIBUTION_URL = "https://services.gradle.org/distributions/gradle-9.7.1-bin.zip"
    private const val SHA256 = "acd53f1edaf02f1a8ff99879f8a34b302661a057d9b063ae9e35b552f804d20a"

    @JvmStatic
    fun main(args: Array<String>) {
        val project = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize()
        val home = Paths.get(System.getProperty("user.home"))
        val base = home.resolve(".gradle").resolve("wrapper").resolve("dists").resolve("mr-x-gradle-$VERSION")
        val zip = base.resolve("gradle-$VERSION-bin.zip")
        val dist = base.resolve("gradle-$VERSION")
        val gradle = dist.resolve("bin").resolve(if (isWindows()) "gradle.bat" else "gradle")

        Files.createDirectories(base)
        if (!Files.isRegularFile(gradle)) {
            if (!Files.isRegularFile(zip) || !SHA256.equals(sha256(zip), ignoreCase = true)) {
                Files.deleteIfExists(zip)
                System.err.println("Downloading Gradle $VERSION distribution...")
                download(DISTRIBUTION_URL, zip)
                val actual = sha256(zip)
                if (!SHA256.equals(actual, ignoreCase = true)) {
                    Files.deleteIfExists(zip)
                    throw IOException("Gradle distribution SHA-256 mismatch. Expected $SHA256, got $actual")
                }
            }
            extract(zip, base)
            if (!Files.isRegularFile(gradle)) {
                throw IOException("Gradle distribution extracted, but executable was not found: $gradle")
            }
        }

        val command = mutableListOf<String>()
        if (isWindows()) {
            command += "cmd.exe"
            command += "/c"
            command += gradle.toString()
        } else {
            command += gradle.toString()
        }
        command += args

        val process = ProcessBuilder(command)
            .directory(project.toFile())
            .inheritIO()
        process.environment().putIfAbsent("GRADLE_USER_HOME", home.resolve(".gradle").toString())
        exitProcess(process.start().waitFor())
    }

    private fun exitProcess(code: Int): Nothing = kotlin.system.exitProcess(code)

    private fun isWindows(): Boolean =
        System.getProperty("os.name", "").lowercase(Locale.ROOT).contains("win")

    private fun download(url: String, out: Path) {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 15_000
            readTimeout = 60_000
            setRequestProperty("User-Agent", "MR-X-Gradle-Bootstrap/1.0")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IOException("Gradle download failed with HTTP $code")
            connection.inputStream.use { input ->
                Files.newOutputStream(out).use { output ->
                    val buffer = ByteArray(1024 * 128)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun sha256(path: Path): String {
        val digest = MessageDigest.getInstance("SHA-256")
        Files.newInputStream(path).use { input ->
            val buffer = ByteArray(1024 * 128)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(Locale.ROOT, it) }
    }

    private fun extract(zip: Path, base: Path) {
        var root: String? = null
        ZipInputStream(Files.newInputStream(zip)).use { input ->
            val buffer = ByteArray(1024 * 128)
            while (true) {
                val entry = input.nextEntry ?: break
                val name = entry.name.replace('\\', '/')
                if (name.isEmpty() || name.startsWith('/') || name.contains("../") || name.contains("..\\")) {
                    throw IOException("Unsafe Gradle archive entry: $name")
                }

                val slash = name.indexOf('/')
                if (slash > 0 && root == null) root = name.substring(0, slash)

                val target = base.resolve(name).normalize()
                if (!target.startsWith(base)) throw IOException("Archive traversal detected: $name")

                if (entry.isDirectory) {
                    Files.createDirectories(target)
                } else {
                    Files.createDirectories(target.parent)
                    Files.newOutputStream(target).use { output ->
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            output.write(buffer, 0, count)
                        }
                    }
                }
                input.closeEntry()
            }
        }

        val extractedRoot = root ?: throw IOException("Empty Gradle distribution archive")
        if (extractedRoot != "gradle-$VERSION") {
            val actual = base.resolve(extractedRoot)
            val expected = base.resolve("gradle-$VERSION")
            if (Files.exists(expected)) deleteTree(expected)
            Files.move(actual, expected, StandardCopyOption.REPLACE_EXISTING)
        }
        Files.deleteIfExists(zip)
    }

    private fun deleteTree(path: Path) {
        if (!Files.exists(path)) return
        Files.walk(path).use { stream ->
            stream.sorted(Comparator.reverseOrder()).forEach { Files.deleteIfExists(it) }
        }
    }
}
