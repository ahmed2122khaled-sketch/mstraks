#!/usr/bin/env python3
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
gradle = (ROOT / "app/build.gradle.kts").read_text()
root_gradle = (ROOT / "build.gradle.kts").read_text()
manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()

def check(ok, label):
    print(("PASS: " if ok else "FAIL: ") + label)
    if not ok:
        raise SystemExit(1)

check('compileSdk = 37' in gradle, 'compileSdk 37 / Android 17')
check('targetSdk = 37' in gradle, 'targetSdk 37 / current 2026 Play-compatible target')
check('minSdk = 21' in gradle, 'minimum SDK remains API 21 for broad legacy-device coverage')
check('versionCode = 52' in gradle and 'versionName = "2.19.7"' in gradle, 'current release metadata is unique and current')
check('com.android.application") version "9.3.3"' in root_gradle, 'AGP 9.3.3 patch level')
check('androidx.activity:activity-ktx:1.13.0' in gradle, 'Activity 1.13.0 stable 2026 dependency')
check('androidx.core:core-ktx:1.19.1' in gradle, 'Core 1.19.1 stable 2026 dependency')
check(not list((ROOT / 'app/src').rglob('*.java')), 'no Java source files')
check(not list((ROOT / 'app/src').rglob('*.kt')) == [], 'Kotlin source tree is present')
uses = {e.attrib.get('{http://schemas.android.com/apk/res/android}name'): e for e in manifest.findall('uses-feature')}
cam = uses.get('android.hardware.camera.any')
check(cam is not None and cam.attrib.get('{http://schemas.android.com/apk/res/android}required') == 'false', 'camera remains optional')
app = manifest.find('application')
check(app is not None and app.attrib.get('{http://schemas.android.com/apk/res/android}resizeableActivity') == 'true', 'large screens/foldables remain resizeable')
check(app is not None and app.attrib.get('{http://schemas.android.com/apk/res/android}supportsRtl') == 'true', 'RTL support remains enabled')
check(app is not None and app.attrib.get('{http://schemas.android.com/apk/res/android}usesCleartextTraffic') == 'false', 'cleartext traffic remains disabled')
check(not re.search(r'android\.permission\.READ_EXTERNAL_STORAGE', (ROOT/'app/src/main/AndroidManifest.xml').read_text()), 'legacy broad read-storage permission is absent')
print('ANDROID 2026 COMPATIBILITY VERIFICATION: PASS')
