# mr.x — Kotlin Migration Step 5

This step moves the offline synchronization orchestration out of `MainActivityLegacy.java` into `core/KotlinOfflineSyncCoordinator.kt`.

Moved responsibilities:
- account-scoped pending-operation loading
- binding legacy unbound queue rows to the active account
- retry/attempt limits
- offline post/story dispatch
- authenticated request + refresh retry
- success/permanent-client-error deletion rules
- retry status reporting and rescheduling callback

`MainActivityLegacy.java` now acts as a compatibility boundary and delegates the synchronization operation to the Kotlin coordinator.

The legacy Java activity is intentionally retained because other UI/auth/media behavior has not yet been fully migrated.
