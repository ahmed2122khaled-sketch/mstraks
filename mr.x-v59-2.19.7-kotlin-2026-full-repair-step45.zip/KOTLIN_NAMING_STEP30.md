# Kotlin naming cleanup — Step 30

This step normalizes active Kotlin source filenames and removes migration-era names.

Changes:
- `MigrationUtils.kt` → `AppUtils.kt` (`MigrationUtils` → `AppUtils`)
- `MainActivitySupport.kt` → `AuthUtils.kt` (`MainActivitySupport` → `AuthUtils`)
- `NetworkModels.kt` was split into:
  - `HttpResult.kt`
  - `UploadedMedia.kt`
  - `OfflineException.kt`
- Existing component-oriented Kotlin names such as `MainActivity.kt`, `OfflineStore.kt`,
  `ConnectivityMonitor.kt`, `SecretStore.kt`, `ServiceClients.kt`, and
  `ServiceEndpoints.kt` were kept because they already match their primary types.

No Java source was reintroduced. Active Android source remains Kotlin-only.
