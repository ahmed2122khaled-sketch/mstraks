# Mr.x — Full Repair Audit — 2026-09-25

This pass starts from Kotlin Step 33 and applies one coordinated repair pass across source, networking, offline storage, media handling, authentication callbacks, permissions, and 2026 Android targeting.

## Repairs
- Fixed missing `ServiceClients.Client.baseUrl()` API used by the application.
- Restored the complete service-routing contract: trusted origins, read-replica detection, and write fallback.
- Hardened service-origin comparison so ports and origins cannot be confused and URL paths do not weaken trust checks.
- Fixed the authentication callback path comparison bug.
- Enforced UUID validation for the authenticated Supabase user identity before caching it.
- Hardened offline media cleanup so only files directly inside the app's `offline-media` directory can be consumed by the sync path.
- Rejected unsupported media MIME types before creating offline files or upload paths.
- Added a trusted-origin check before direct Storage uploads.
- Replaced line-based response parsing with a byte-limited reader to enforce the response-size limit before constructing the response String.
- Migrated camera permission handling to the Activity Result multiple-permission contract and added legacy external-storage permission only through API 28.
- Preserved cleartext blocking, backup exclusions, FLAG_SECURE, no-WebView architecture, and redirect blocking.
- Updated Android targeting to API 37 (Android 17) for 2026 compatibility; the project must have the Android 17 SDK installed to build.
- Updated release metadata to version 2.19.0 / versionCode 45.

## Current tooling baseline
- Android Gradle Plugin: 9.4.1
- Kotlin: 2.4.20
- Gradle wrapper: 9.7.1
- compileSdk / targetSdk: 37
- Java/Kotlin JVM target: 17
- AndroidX Activity KTX: 1.13.0
- AndroidX Core KTX: 1.19.1

## Verification
Static completeness, service isolation, hardening, regression, offline, security, native-only, and free-policy checks pass after this repair pass. A full Android Gradle build was attempted but the execution environment cannot reach services.gradle.org and does not contain the Android SDK, so no false APK-build success is claimed.
