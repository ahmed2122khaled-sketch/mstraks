plugins {
    id("com.android.application") version "9.3.3" apply false
}
