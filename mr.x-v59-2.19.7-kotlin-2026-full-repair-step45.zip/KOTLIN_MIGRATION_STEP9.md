# Kotlin Migration Step 9

## What was changed
- Removed the invalid/incomplete generated `MainActivityLegacy.kt` conversion from the previous checkpoint.
- Preserved `MainActivityLegacy.java` as the source of truth so the project is not left with syntactically broken Kotlin.
- `GradleBootstrap.java` was already fully migrated to `GradleBootstrap.kt` in Step 7.

## MainActivityLegacy
`MainActivityLegacy.java` is the remaining large Android application source. It is intentionally not replaced by a regex-generated `.kt` file because that would introduce invalid Kotlin around Android callbacks, SAM/anonymous classes, lambdas, try-with-resources, nullable fields, and Java/Kotlin API differences.

The next real migration must convert this complete class with an AST/J2K-capable converter and then perform Kotlin-specific fixes before deleting the Java source.
