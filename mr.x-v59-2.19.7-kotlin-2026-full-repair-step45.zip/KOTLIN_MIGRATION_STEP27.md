# Kotlin Migration — Step 27

This step continues the full Java-to-Kotlin cleanup on the actual application source.

## Changes

- Removed remaining Java collection construction syntax from application Kotlin sources.
- Replaced `HashSet`, `HashMap`, and `LinkedHashSet` constructions with Kotlin collection builders.
- Replaced a legacy `Pattern` allocation in email validation with a reusable Kotlin `Regex`.
- Replaced per-call UUID regex allocation with a reusable Kotlin `Regex`.
- Removed a redundant nullable check after `Uri.decode`.
- Simplified connectivity callback registration so the callback is non-null before registration.
- Expanded several compressed one-line media/session helpers into readable Kotlin functions.
- Used `runCatching` for small exception-safe Kotlin helpers where behavior is unchanged.
- Preserved Android API 21 compatibility and existing application behavior.

## Verification

- Java source files under `app/src/main/kotlin`: 0
- Kotlin source files under `app/src/main/kotlin`: 16
- Kotlin null assertions (`!!`) under application source: 0
- Java collection constructors under application source: 0
- Full Android APK build is not claimed in this environment because the Android SDK/toolchain is unavailable.
