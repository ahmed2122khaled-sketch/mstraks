# Kotlin / Android 2026 Modernization — Step 21

## Applied changes

- Fixed `app/build.gradle.kts` so the `dependencies {}` block is at project/module scope instead of nested inside `android {}`.
- Kept current stable AndroidX Activity 1.13.0 and upgraded Core usage to `androidx.core:core-ktx:1.19.1`.
- Added Java 17 source/target compatibility for the Android module.
- Continued Kotlin-side replacement of obsolete Java-style Android accessors in `MainActivityLegacy.kt`: `window`, `intent`, `isFinishing`, `contentResolver`, `Uri` properties, and `TextView.text`.
- Removed an impossible nullable check from `currentOperationId()` and replaced it with `isBlank()`.
- Updated SQLite helper access in `OfflineStore.kt` to Kotlin properties (`readableDatabase` / `writableDatabase`).
- No Java source files were introduced; the app source remains Kotlin-only.

## Verification note

Static source checks can run in this environment. A complete Android APK build still requires the Android SDK/Gradle toolchain to be available.
