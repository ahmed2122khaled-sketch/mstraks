# Kotlin Migration Step 8

## Scope
A full-file conversion pass was started against `MainActivityLegacy.java` rather than moving individual methods.

## Important status
The source is a large Android Activity (1,670 lines) using Android framework APIs, Java lambdas/SAM syntax, Java local-variable declarations, try-with-resources, checked-exception declarations, and several Java-specific constructs. A blind regex conversion produces invalid Kotlin in several places.

This checkpoint therefore **does not delete the Java source** and is **not marked final**. The Java source remains the authoritative implementation until a syntax-safe conversion is completed.

## Why Java remains
The available environment has no Android SDK/Android Studio and no standalone J2K engine. Kotlin's official J2K tooling is normally provided by IntelliJ/Android tooling, and converted code can require manual fixes. Delivering a broken `.kt` file as if it were a complete migration would be misleading.

## Next full-file conversion target
`app/src/main/kotlin/com/socialnetwork/app/MainActivityLegacy.java`

The intended final state is:
- `MainActivity.kt` contains the actual Activity implementation.
- `MainActivityLegacy.java` is removed.
- No app Java source remains.
- Imports, Android callbacks, lambdas, nullability, resource access, and Java interop are corrected.
